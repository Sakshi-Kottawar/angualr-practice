export interface Question {
    id: number,
    question_text: string,
    answer_options: any[],
    correct_answer: string,
    author: string
}
