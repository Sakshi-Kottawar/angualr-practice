import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Question } from '../question';
import { User } from '../user';

@Injectable({
  providedIn: 'root'
})
export class AutheticationService {

  private auth_url: string = "../../assets/data/user.json";
  private ques_url: string = "../../assets/data/questions.json";
  private isAuthenticUser: boolean = false;
  constructor(private http: HttpClient) { }


  get(): Observable<User[]> {
    return this.http.get<User[]>(this.auth_url);
  }

  getQuestions(): Observable<Question[]> {
    return this.http.get<Question[]>(this.ques_url);
  }

  getAuthenticUserFlag() {
    return this.isAuthenticUser;
  }
  setAuthenticUserFlag(user: boolean) {
    this.isAuthenticUser = user;
  }



}
