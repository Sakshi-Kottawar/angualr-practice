import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AutheticationService } from '../shared/authetication.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searchText: string = "";
  apiData: any;
  questionInfo: any[] = [];
  passData: any;
  parent: string = "parent";
  constructor(private authenticationService: AutheticationService, private _router: Router) { }

  ngOnInit(): void {
  }
  submit() {
    this.questionInfo = []
    this.authenticationService.getQuestions().subscribe(data => {
      this.apiData = data
      this.apiData.forEach((element: any) => {
        if (element.question_text.includes(this.searchText)) {
          this.questionInfo.push(element);
        }
      });
    });
  }
  selectedQuestion(item: any) {
    console.log(item);
    this.passData = item;
    this._router.navigate(['question'], { state: this.passData })
  }

}
