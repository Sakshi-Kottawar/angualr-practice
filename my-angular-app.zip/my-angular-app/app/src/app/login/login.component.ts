import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AutheticationService } from '../shared/authetication.service';
import { User } from '../user';
import { MatFormFieldModule } from '@angular/material/form-field';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public user: User[] = [];
  username: string = "";
  password: string = "";
  apiuser: any;
  isError: boolean = false;

  constructor(private authenticationService: AutheticationService,
    private _router: Router) { }

  ngOnInit(): void {

  }
  submit() {
    console.log(this.username)
    this.authenticationService.get().subscribe(data => {
      this.user = data
      this.apiuser = this.user.find(({ username }) => username === this.username)

      if (this.apiuser && this.apiuser.password === this.password) {
        this.authenticationService.setAuthenticUserFlag(true)
        this._router.navigate(['search'])
      }
      if (!this.apiuser || this.apiuser.password !== this.password) {
        this.isError = true;
        this.username = "";
        this.password = "";
      }
    });
  }

}
